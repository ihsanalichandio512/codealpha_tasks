const ageCalculator = () => {
    let dobInput = document.getElementById('dob');
    let dob = new Date(dobInput.value);
    let today = new Date();
  
    // Check if the entered date is in the future
    if (dob > today) {
      alert("Please enter a valid birthdate in the past.");
      return;
    }
  
    // Check if the birthdate field is empty
    if (dobInput.value === "") {
      alert("Please enter your birthdate.");
      return;
    }
  
    let age = today.getFullYear() - dob.getFullYear();
    let months = today.getMonth() - dob.getMonth();
    let days = today.getDate() - dob.getDate();
  
    if (months < 0 || (months === 0 && days < 0)) {
      age--;
    }
  
    document.getElementById('age').innerHTML = `You are ${age} Years, ${months} Months, And ${days} Days Old.`;
  };